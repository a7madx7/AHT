from django.db import models


# Create your models here.
class Salary(models.Model):
    basic = models.PositiveIntegerField(verbose_name='Employee Basic Salary', name='Basic')
    incentive = models.FloatField(verbose_name='This month incentive', name='Employee Incentive')
    bonus = models.FloatField(verbose_name='This month bonus', name='Employee Bonus')
    special_list_value = models.FloatField(verbose_name='This month special list value', name='Special List Value')
    special_list_percentage = models.FloatField(verbose_name='This month special list percentage',
                                                name='Special List %')
    sales_cut = models.FloatField(verbose_name='This month sales cut', name='Sales Cut')
    housing_allowance = models.FloatField(verbose_name='This month incentive', name='Employee Incentive', default=1416.67)
    transport_allowance = models.FloatField(verbose_name='This month transport allowance', name='Employee transport allowance', blank=True)
    overtime = models.FloatField(verbose_name='This month overtime', name='Employee Overtime')
    discount = models.FloatField(verbose_name='Applied discounts on the Pharmacist', name='Applied discounts', default=0, blank=True)

    class Meta:
        ordering = ['special_list_value']


class Employee(models.Model):
    first_name = models.CharField(max_length=33)
    middle_name = models.CharField(max_length=33, blank=True)
    last_name = models.CharField(max_length=33, blank=True)
    salary = models.ForeignKey(Salary, on_delete=models.CASCADE)
    work_start_date = models.DateField(blank=True)
    # todo: know how to implement properly in django
    created_at = models.DateTimeField(auto_now_add=True, blank=False)
    updated_at = models.DateTimeField(auto_now_add=True, blank=False)

    residency_renewal_cost = models.FloatField(verbose_name='Cost of residency renewal', name='Residency cost', blank=True)
    residency_renewal_date = models.DateField(verbose_name='When the employee residency will expire',
                                              name='residency expiry date', blank=True)

    class Meta:
        ordering = ['salary.special_list_value']
