from django.db import models
from django.contrib.auth.models import User


class Employee(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, blank=True, null=True)

    work_start_date = models.DateField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now_add=True)

    residency_renewal_cost = models.FloatField(verbose_name='Cost of residency renewal', name='Residency cost',
                                               blank=True)
    residency_renewal_date = models.DateField(verbose_name='When the employee residency will expire',
                                              name='Residency expiry date', blank=True)

    def __str__(self):
        if self.user is None:
            return 'Unassociated Employee!'
        else:
            if self.user.first_name == '':
                return 'Unnamed Employee!'
            else:
                return f'{self.user.first_name} {self.user.last_name}'

    class Meta:
        ordering = ['work_start_date']


# Create your models here.
class Salary(models.Model):
    employee = models.OneToOneField(Employee, on_delete=models.CASCADE)

    basic = models.PositiveIntegerField(verbose_name='Employee Basic Salary', name='Basic', default=4500)
    incentive = models.FloatField(verbose_name='This month incentive', name='Employee Incentive', default=0)
    bonus = models.FloatField(verbose_name='This month bonus', name='Employee Bonus', default=0)
    special_list_value = models.FloatField(verbose_name='This month special list value',
                                           name='Special List Value', default=0)
    special_list_percentage = models.FloatField(verbose_name='This month special list percentage',
                                                name='Special List Percentage', default=0)

    sales_cut = models.FloatField(verbose_name='This month sales cut', name='Sales Cut', default=0)
    total_sales_value = models.FloatField(verbose_name='This month total sales value',
                                          name='Total sales value', default=0)
    list_sales_value = models.FloatField(verbose_name='This month total sales value',
                                         name='List sales value', default=0)

    housing_allowance = models.FloatField(verbose_name='This month housing allowance', name='Housing allowance',
                                          default=1416.67)
    transport_allowance = models.FloatField(verbose_name='This month transport allowance',
                                            name='Employee transport allowance', blank=True, default=0)
    overtime_hrs = models.FloatField(verbose_name='This month overtime', name='Employee Overtime', default=24)
    discount = models.FloatField(verbose_name='Applied discounts on the Pharmacist', name='Applied discounts',
                                 default=0, blank=True)

    total_salary = models.FloatField(verbose_name='This month total salary value for that user',
                                     name='Total salary value', default=6000)

    def _sales_cut(self):
        return float((self.total_sales_value - self.list_sales_value) * 0.01)

    def _total_salary(self):
        return float(
            self.basic + self.incentive + self.bonus + self.special_list_value
            + self.sales_cut + self.housing_allowance + self.transport_allowance
            + (self.overtime_hrs * 17.308 * 1.50) - self.discount
        )

    def save(self, *args, **kwargs):
        self.sales_cut = self._sales_cut()
        self.total_salary = self._total_salary()
        super(Salary, self).save(*args, **kwargs)

    def __str__(self):
        return f'{self._total_salary()} SAR'

    class Meta:
        ordering = ['Special List Value']


class Evaluation(models.Model):
    employee = models.OneToOneField(Employee, on_delete=models.CASCADE, blank=True, null=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now_add=True)
    month = models.CharField(max_length=2, blank=True)
    points_gained = models.SmallIntegerField(default=0)
    points_max = models.SmallIntegerField(default=60)
    kpi = models.FloatField(default=33.0)

    def _kpi(self):
        return float((self.points_gained / self.points_max) * 100.0)

    def save(self, *args, **kwargs):
        self.kpi = self._kpi()
        super(Evaluation, self).save(*args, **kwargs)

    def __str__(self):
        return f'Evaluation KPI {self.kpi}%'

    class Meta:
        ordering = ['points_gained']