from rest_framework import serializers
from django.contrib.auth.models import User

from .models import Employee, Salary, Evaluation


class SalarySerializer(serializers.ModelSerializer):
    class Meta:
        model = Salary
        fields = ('basic', 'incentive', 'bonus', 'special_list_value', 'special_list_percentage', 'sales_cut',
                  'housing_allowance', 'transport_allowance', 'overtime', 'discount')


class EvaluationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Evaluation
        fields = ('created_at', 'updated_at', 'month', 'points_gained', 'points_max', 'kpi')


class EmployeeSerializer(serializers.ModelSerializer):
    salary = SalarySerializer()
    evaluation = EvaluationSerializer()

    class Meta:
        model = Employee
        fields = ('work_start_date', 'created_at', 'updated_at', 'residency_renewal_cost', 'residency_renewal_date')


class UserSerializer(serializers.ModelSerializer):
    employee = EmployeeSerializer()

    class Meta:
        model = User
        fields = ('id', 'username', 'first_name', 'last_name', 'is_staff', 'is_superuser')



